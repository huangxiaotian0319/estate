package test.domain;

public class DynamicReviewWithBLOBs extends DynamicReview {
    private String content;

    private String data;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data == null ? null : data.trim();
    }
}